
/*------------------------------------------------------------------------
    File        : GetAddress.p
    Purpose     : 

    Syntax      :

    Description : 

    Author(s)   : prajain
    Created     : Wed Jul 27 14:47:57 IST 2022
    Notes       :
  ----------------------------------------------------------------------*/

/* ***************************  Definitions  ************************** */

BLOCK-LEVEL ON ERROR UNDO, THROW.

/* ********************  Preprocessor Definitions  ******************** */


/* ***************************  Main Block  *************************** */
procedure getEmpAddr:
def input param CustNum as int no-undo.
def output param address as char no-undo.
find first Customer no-lock
where Customer.custnum = CustNum
no-error.
if avail Customer then
address = Substitute("CustNum &1, Address:&2",CustNum,Customer.Address).
else
address = Substitute("Customer not found for custNum &1",CustNum).
end procedure.