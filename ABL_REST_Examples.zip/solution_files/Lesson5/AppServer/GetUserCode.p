/*------------------------------------------------------------------------
    File        : GetUserCode.p
    Purpose     : 

    Syntax      :

    Description : 

    Author(s)   : Jagdish
    Created     : Tue Jul 19 16:54:46 EDT 2022
    Notes       :
  ----------------------------------------------------------------------*/

/* ***************************  Definitions  ************************** */

BLOCK-LEVEL ON ERROR UNDO, THROW.

/* ********************  Preprocessor Definitions  ******************** */


/* ***************************  Main Block  *************************** */
DEFINE VARIABLE hCPIn   AS HANDLE.
DEFINE VARIABLE hCPOut  AS HANDLE.
DEFINE VARIABLE cUserID AS CHARACTER NO-UNDO.

hCPIn = SESSION:CURRENT-REQUEST-INFO:GetClientPrincipal().
cUserID = hCPIn:USER-ID.
message "User id of current user is: " cUserID.
message hCPIn:Roles.
message hCPIn:INSTANTIATING-PROCEDURE.
message hCPIn:SESSION-ID.
message hCPIn:DOMAIN-NAME. 

if hCPIn:Roles <> "ROLE_PSCAdmin" then 
    message "You are not admin. You cannot delete any records.".